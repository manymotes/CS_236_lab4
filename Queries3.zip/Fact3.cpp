#include "Fact3.h"

Fact::Fact(vector<Predicate> list) {

}