#pragma once
#include <vector>

using namespace std;
class Tuple : vector<string>
{
};
/*
tuple
inherit a vector of strings via buplic vector
*/