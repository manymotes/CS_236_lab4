#include "Queries3.h"

Query::Query(vector<Predicate> qlist) {

}