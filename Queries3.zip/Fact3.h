#pragma once
#include "Predicate3.h"
#include <vector>

class Fact {
public:
	Fact(vector<Predicate> list);

private:
};